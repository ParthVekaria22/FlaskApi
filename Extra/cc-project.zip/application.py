from flask import Flask, request, jsonify
import base64
import numpy as np
import cv2

application = Flask(__name__)

@application.route('/compress', methods=['POST'])
def compress():
    # Get the image data from the request
    json_data = request.get_json()
    image_base64 = json_data['image']

    # Decode the base64-encoded image data
    image_data = base64.b64decode(image_base64)

    # Convert the image data to a NumPy array
    image_array = np.frombuffer(image_data, dtype=np.uint8)

    # Decode the NumPy array as an image using OpenCV
    image = cv2.imdecode(image_array, flags=cv2.IMREAD_COLOR)

    # Compress the image using JPEG compression
    _, compressed_image_data = cv2.imencode('.jpg', image, [cv2.IMWRITE_JPEG_QUALITY, 50])

    # Encode the compressed image data as a base64 string
    compressed_image_base64 = base64.b64encode(compressed_image_data).decode('utf-8')

    # Create a JSON response containing the compressed image data
    response_data = {
        'compressed_image': compressed_image_base64
    }
    # Return the JSON response
    return jsonify(response_data)


if __name__ == '__main__':
    application.run(debug=True)
